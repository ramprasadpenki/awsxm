from django.contrib import admin

from .models import *

admin.site.register(info_request)
admin.site.register(donate)
